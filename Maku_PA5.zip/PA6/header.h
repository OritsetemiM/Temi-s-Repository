#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h> 
#include <stdlib.h> 
#include <time.h> // time () void display_menu(void); 
void print_game_rules(void); // function that will print out the game rules 
int game_menu_choice(); //determines if the user wants to display rules, play the game, or exit
void roll_dice(int dice[], int size); //function that will put random numbers in to array to be used as dice 
void display_dice(int dice[], int size); //prints the dice for the user to see 
void reroll_dice(int dice[], int size); // user gets to choose which dice to reroll after the first roll 
int sum_of_numbers(int dice[], int number); // sum of number categories for scoring points
int three_of_a_kind(int dice[], int size); // adds all the numbers if a dice number is shown three times after rolling
int four_of_a_kind(int dice[], int size);  // adds all the numbers if a dice number is shown four times after rolling
int yahtzee(int dice[], int size); // all die have the same number resulting in + 50 to the players score
int chance(int dice[], int size); // just adds all of the dice numbers together and adds them
int full_house(int dice[], int size); // if the player get a pair of a dice number and a triple of another dice number then the user gets 25 points
int small_straight(int dice[], int size); // A sequence of four die is rolled, results in + 30 added to the players score
int large_straight(int dice[], int size); // A sequence of five die is rolled, results in + 40 added to the players score
void init_scorecard(int* scorecard_ptr, int size); // initiallizes the scorebaord to -1's which means nothing has been added to the scoreboard yet
void display_scorecard(int* scorecard_ptr, int size); // displays the scoreboard to the screen for the user
void score_to_scorecard(int* scorecard_ptr, int size, int index, int score); // shows the score on the scoreboard for the user to see