#include "header.h"

int main(void)
{
	// dice, p1_scorecard, p2_scorecard is useful for PA 5.
	int dice[5] = { 0 },
		p1_scorecard[14] = { 0 },
		p2_scorecard[14] = { 0 },
		p1_freq[14] = { 0 },
		p2_freq[14] = { 0 };

	srand(time(NULL)); //useful for random number generator
	int menu = 0;
	//calculates the players scores
	int p1_score = 0;
	int p1_total = 0;
	int p2_score = 0;
	int p2_total = 0;
	//keeps track of the roll count so that it isn't above 3
	int roll_count1 = 0;
	int roll_count2 = 0;
	//keeps track of the score choice number that the user inputted
	int score_choice = 0;
	//keeps track of the number of rounds during the game
	int rounds = 1;
	// makes sure the loop still runs even after the user rolls more than three times rather than breaking from the while loop
	//and breaking the game
	int loop_control1 = 0;
	int loop_control2 = 0;
	do {
		menu = game_menu_choice();
		if (menu == 2)
		{
			print_game_rules();
			system("pause");
			printf("************************************************************\n");
		}
		else if (menu == 1)
		{
			system("cls");
			printf("LETS PLAY YAHTZEE!!\n");
			system("pause");
			init_scorecard(p1_scorecard, 14);
			init_scorecard(p2_scorecard, 14);
			printf("************************************************************\n");
			while (rounds <= 13) 
			{
				if (loop_control1 == 0)
				{
					system("cls");
					printf("round %d out of 13\n", rounds);
					rounds++;
					printf("************************************************************\n");
					printf("Player 1's Turn!\n");
					printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
					display_scorecard(p1_scorecard, 14);
					system("pause");
					printf("************************************************************\n");
					printf("Player 1 rolled... \n");
					system("pause");
					roll_dice(dice, 5);
					display_dice(dice, 5);
					system("pause");
					printf("************************************************************\n");
				}
				roll_count1 = 0;
				while (roll_count1 != 3)
				{
					loop_control1 = 1;
					printf("DICE YOU ROLLED: ");
					display_dice(dice, 5);
					printf("WHICH COMBINATION DO YOU CHOOSE? (Please don't reroll dice more than 3 times)\n");
					printf("Sum of 1's: (1)\n");
					printf("Sum of 2's: (2)\n");
					printf("Sum of 3's: (3)\n");
					printf("Sum of 4's: (4)\n");
					printf("Sum of 5's: (5)\n");
					printf("Sum of 6's: (6)\n");
					printf("Three-of-a-kind: (7)\n");
					printf("Four-of-a-kind: (8)\n");
					printf("Full house: (9)\n");
					printf("Small straight: (10)\n");
					printf("Large straight: (11)\n");
					printf("Yahtzee: (12)\n");
					printf("Chance: (13)\n");
					printf("Roll Again: (14)\n");
					scanf("%d", &score_choice);
					if (score_choice >= 1 && score_choice <= 6)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = sum_of_numbers(dice, score_choice);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 7)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = three_of_a_kind(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 8)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = four_of_a_kind(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 9)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = full_house(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 10)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = small_straight(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 11)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = large_straight(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 12)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = yahtzee(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 13)
					{
						if (p1_freq[score_choice] == 1)
						{
							printf("You already used this option, please choose another option!\n");
							continue;
						}
						p1_freq[score_choice] = 1;
						p1_score = chance(dice, 5);
						printf("You added %d to your score!! \n", p1_score);
						printf("PlAYER 1 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						score_to_scorecard(p1_scorecard, 14, score_choice, p1_score);
						display_scorecard(p1_scorecard, 14);
						p1_total += p1_score;
						system("pause");
						printf("************************************************************\n");
						roll_count1 = 3;
						loop_control1 = 0;
					}
					else if (score_choice == 14)
					{
						if (roll_count1 >= 2)
						{
							printf("No more rolls! Please pick an option or game will crash!\n");
							continue;
						}
						printf("DICE YOU ROLLED: ");
						display_dice(dice, 5);
						roll_count1++;
						printf("Player 1 rerolling... \n");
						reroll_dice(dice, 5);
						system("pause");
						display_dice(dice, 5);
						system("pause");
						printf("************************************************************\n");
						continue;
					}
					system("cls");
					if (loop_control2 == 0)
					{
						printf("************************************************************\n");
						printf("Player 2's Turn\n");
						printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
						display_scorecard(p2_scorecard, 14);
						system("pause");
						printf("************************************************************\n");
						printf("Player 2 rolled... \n");
						system("pause");
						roll_dice(dice, 5);
						display_dice(dice, 5);
						system("pause");
						printf("************************************************************\n");
					}
					roll_count2 = 0;
					while (roll_count2 != 3)
					{
						loop_control2 = 0;

						printf("WHICH COMBINATION DO YOU CHOOSE? (Please don't reroll dice more than 3 times) \n");
						printf("DICE YOU ROLLED: ");
						display_dice(dice, 5);
						printf("Sum of 1's: (1)\n");
						printf("Sum of 2's: (2)\n");
						printf("Sum of 3's: (3)\n");
						printf("Sum of 4's: (4)\n");
						printf("Sum of 5's: (5)\n");
						printf("Sum of 6's: (6)\n");
						printf("Three-of-a-kind: (7)\n");
						printf("Four-of-a-kind: (8)\n");
						printf("Full house: (9)\n");
						printf("Small straight: (10)\n");
						printf("Large straight: (11)\n");
						printf("Yahtzee: (12)\n");
						printf("Chance: (13)\n");
						printf("Roll Again: (14)\n");
						scanf("%d", &score_choice);
						if (score_choice >= 1 && score_choice <= 6)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = sum_of_numbers(dice, score_choice);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 7)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = three_of_a_kind(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 8)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = four_of_a_kind(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 9)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = full_house(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 10)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = small_straight(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 11)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = large_straight(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 12)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = yahtzee(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 13)
						{
							if (p2_freq[score_choice] == 1)
							{
								printf("You already used this option, please choose another option!\n");
								continue;
							}
							p2_freq[score_choice] = 1;
							p2_score = chance(dice, 5);
							printf("You added %d to your score!! \n", p2_score);
							printf("PlAYER 2 SCORECARD (-1's means there is nothing in the scorecard yet) \n");
							score_to_scorecard(p2_scorecard, 14, score_choice, p2_score);
							display_scorecard(p2_scorecard, 14);
							p2_total += p2_score;
							system("pause");
							printf("************************************************************\n");
							roll_count2 = 3;
							loop_control2 = 0;
						}
						else if (score_choice == 14)
						{
							if (roll_count2 >= 2)
							{
								printf("No more rolls! Game has crashed please run again! \n");
								continue;
							}
							roll_count2++;
							printf("DICE YOU ROLLED: ");
							display_dice(dice, 5);
							printf("Player 2 rerolling... \n");
							reroll_dice(dice, 5);
							system("pause");
							display_dice(dice, 5);
							system("pause");
							printf("************************************************************\n");
							continue;
						}
						printf("\n");
					}

				}

			}
			printf("Game Over!\n");
			system("pause");
			printf("************************************************************\n");
			int check1_sum_number = 0;
			int check2_sum_number = 0;
			for (int i = 0; i > 6; i++)
			{
				check1_sum_number += p1_scorecard[i];
				check2_sum_number += p2_scorecard[i];
			}
			if (check1_sum_number >= 63)
			{
				printf("Player 1 got a bounus!! \n");
				p1_total += check1_sum_number;
			}
			if (check2_sum_number >= 63)
			{
				printf("Player 2 got a bounus!! \n");
				p2_total += check2_sum_number;
			}
			if (p1_total > p2_total)
			{
				printf("Player 1 won the game!!\n");
				printf("The final score was P1: %d to P2: %d", p1_total, p2_total);
				system("pause");
				printf("************************************************************\n");
				printf("\n");
			}
			else if (p1_total < p2_total)
			{
				printf("Player 1 won the game!!\n");
				printf("The final score was P1: %d to P2: %d\n", p1_total, p2_total);
				system("pause");
				printf("************************************************************\n");
				printf("\n");
			}
			else
			{
				printf("The game ended in a tie!!\n");
				printf("The final score was P1: %d to P2: %d\n", p1_total, p2_total);
				system("pause");
				printf("************************************************************\n");
			}
		}
		else if(menu == -1)
		{
			printf("Invalid Answer! Please input a valid letter!\n");
			system("pause");
			printf("************************************************************\n");
		}
	} while (menu != 0);
	printf("THANKS FOR PLAYING!");
	return 0;
}