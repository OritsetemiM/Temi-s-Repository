/* This code will help you get started with PA 6.

	History: 10/27/25 - Implemented function init_board () that sets
						each player's board to all water symbols. Created
						print_board outside of class time.
*/

#include "battleship.h"


int main(void)
{
	char p1_board[MAX_ROWS][MAX_COLS] = { {'\0'} },
		comp_board[MAX_ROWS][MAX_COLS] = { {'\0'} };
	int game_answer;
	int order = 0;
	int game = 0;
	int shot_row1 = 0;
	int shot_col1 = 0;
	int shot_row2 = 0;
	int shot_col2 = 0;
	srand(time(NULL));
	Gamelog p1 = { 0 };
	Gamelog p2 = { 0 };

	
	do
	{
		printf("WOULD YOU LIKE TO PLAY BATTLESHIP?! (0 = exit, 1 = play, 2 = rules)");
		scanf("%d", &game_answer);
		if (game_answer == 0)
		{
			printf("THANKS FOR PLAYING! stats are in the output file \n");
			print_to_file(p1, p2);
		}
		else if (game_answer == 1)
		{
			printf("LETS PLAY!!");
			system("pause");
			init_board(p1_board, MAX_ROWS, MAX_COLS); // initialize the board with all water symbols
			init_board(comp_board, MAX_ROWS, MAX_COLS);

			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			print_board(comp_board, MAX_ROWS, MAX_COLS, 2); // this will hide the ship symbols

			printf("To see who starts first a coin will be flipped...\n");
			printf("Coin being flipped...\n");
			system("pause");
			order = select_who_starts_first();
			if (order == 1)
			{
				printf("YOU WON THE COIN TOSS!\n");
				system("pause");
				system("cls");

			}
			else
			{
				printf("COMPUTER WON THE TOSS!\n");
				system("pause");
				system("cls");
			}
			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			printf("TIME TO PLACE SHIPS!\n");
			place_all_ships(comp_board);
			printf("PlACING THE CARRIER SHIP\n");
			manually_place_ships_on_board(p1_board, 5, 'c');
			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			printf("PlACING THE BATTLESHIP SHIP\n");
			manually_place_ships_on_board(p1_board, 4, 'b');
			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			printf("PlACING THE CRUISER SHIP\n");
			manually_place_ships_on_board(p1_board, 3, 'r');
			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			printf("PlACING THE SUBMARINE SHIP\n");
			manually_place_ships_on_board(p1_board, 3, 's');
			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			printf("PlACING THE DESTROYER SHIP\n");
			manually_place_ships_on_board(p1_board, 2, 'd');

			print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
			print_board(comp_board, MAX_ROWS, MAX_COLS, 2); // this will hide the ship symbols
			system("pause");
			system("cls");
			if (order == 1)
			{
				while (game == 0)
				{
					system("cls");
					shot_check(comp_board, &p1);
					print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
					print_board(comp_board, MAX_ROWS, MAX_COLS, 2); // this will hide the ship symbols
					system("pause");
					system("cls");
					shot_check2(p1_board, &p2);
					print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
					print_board(comp_board, MAX_ROWS, MAX_COLS, 2); // this will hide the ship symbols
					system("pause");
					if ((p1.hits % 17 == 0 && p1.hits != 0) || (p2.hits % 17 == 0 && p2.hits != 0))
					{
						printf("Game Over!");
						game = 1;
					}
				}
			}
			else {
				while (game == 0)
				{
					system("cls");
					shot_check2(p1_board, &p2);
					print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
					print_board(comp_board, MAX_ROWS, MAX_COLS, 2); // this will hide the ship symbols
					system("pause");
					system("cls");
					shot_check(comp_board, &p1);
					print_board(p1_board, MAX_ROWS, MAX_COLS, 1);
					print_board(comp_board, MAX_ROWS, MAX_COLS, 2); // this will hide the ship symbols
					system("pause");
					if ((p1.hits % 17 == 0 && p1.hits != 0) || (p2.hits % 17 == 0 && p2.hits != 0))
					{
						printf("Game Over!");
						game = 1;
					}
				}
			}
			if (p1.hits % 17 == 0)
			{
				printf("PLAYER1 WON THE GAME!\n");
				system("pause");
				system("cls");
				win_loss(1, &p1);
				win_loss(0, &p2);
			}
			else if (p2.hits % 17 == 0)
			{
				printf("COMPUTER WON THE GAME!\n");
				system("pause");
				system("cls");
				win_loss(0, &p1);
				win_loss(1, &p2);
			}
		}
		else if (game_answer == 2)
		{
			print_rules();
			system("pause");
			system("cls");
		}
		else
		{
			printf("INVALID ANSWER!\n");
			system("pause");
		}

	} while (game_answer != 0);
	return 0;
	return 0;
}