#include "battleship.h"
void print_rules()
{
	printf("Battleship is a two player Navy game. The objective of the game is to sink all ships in your enemy's fleet. The player to sink his / her enemy's fleet first wins. Both players' fleets consist of 5 ships that are hidden from the enemy.Each ship may be differentiated by its \"size\" (besides the Cruiser and Submarine) or number of cells it expands on the game board.The Carrier has 5 cells, Battleship has 4 cells, Cruiser has 3 cells, Submarine has 3 cells, and the Destroyer has 2 cells");
}
void init_board(char board[][MAX_COLS], int num_rows, int num_cols)
{
	int row_index = 0, col_index = 0;

	// Nest loops should be used to initialize a 2-D array
	for (; row_index < num_rows; ++row_index) // controls the row
	{
		for (col_index = 0; col_index < num_cols; ++col_index) // controls the column
		{
			board[row_index][col_index] = '~'; // '~' is the water symbols
		}
	}
}

void print_board(char board[][MAX_COLS], int num_rows, int num_cols, int player)
{
	int row_index = 0, col_index = 0;

	if (1 == player)
	{
		puts("Player 1");
	}
	else // computer's board
	{
		puts("Computer");
	}

	// Nested loops should be used to initialize a 2-D array
	// print the column number before entering the loops
	printf("%3d%2d%2d%2d%2d%2d%2d%2d%2d%2d\n", 0, 1, 2, 3, 4, 5, 6, 7, 8, 9);
	for (; row_index < num_rows; ++row_index) // controls the row
	{
		printf("%-2d", row_index); // print the current row number
		for (col_index = 0; col_index < num_cols; ++col_index) // controls the column
		{
			if (2 == player) // computer's board
			{
				// check to see if the current element we're visiting
				// is a ship symbol - if so, mask it with the water symbol
				if (board[row_index][col_index] != 'm' &&
					board[row_index][col_index] != 'h' &&
					board[row_index][col_index] != '~')
				{
					printf("%-2c", '~'); // mask the ship symbol with a water symbol
				}
				else
				{
					printf("%-2c", board[row_index][col_index]); // print the actual symbols stored
				}
			}
			else // player 1
			{
				printf("%-2c", board[row_index][col_index]); // print the actual symbols stored
			}
		}
		putchar('\n'); // set the next symbols to print to the next line in the console
	}
	putchar('\n'); // helps to space out the boards
}

int gen_dir()
{
	return rand() % 2;
}

void gen_start_pt(char board[][MAX_COLS], int ship_len, int dir, int* start_row_pt, int* start_col_pt)
{
	int check = 0;
	while (check == 0)
	{
		if (dir == 0) // horizontal
		{
			*start_row_pt = rand() % MAX_ROWS;
			*start_col_pt = rand() % (MAX_COLS - ship_len + 1);
			check = 1;
			for (int i = 0; i < ship_len; i++)
			{
				if (board[*start_row_pt][*start_col_pt + i] != '~')
				{
					check = 0;
					break;
				}
			}
		}
		else {
			*start_row_pt = rand() % (MAX_ROWS - ship_len + 1);
			*start_col_pt = rand() % MAX_COLS;
			check = 1;
			for (int i = 0; i < ship_len; i++)
			{
				if (board[*start_row_pt + i][*start_col_pt] != '~')
				{
					check = 0;
					break;
				}
			}
		}
	}
}


int select_who_starts_first(void)
{
	int p1 = (rand() % 10) + 1;
	int p2 = (rand() % 10) + 1;
	if (p1 > p2)
	{
		return 1; // player 1 starts
	}
	else if (p1 < p2)
	{
		return 0; // player 2 starts
	}
	else
	{
		return 0; // player 2 still starts cause why not
	}
}

void manually_place_ships_on_board(char board[][MAX_COLS], int ship_len, char symbol)
{
	char dir = 0;
	int check = 0;
	int start_row_pt = 0;
	int start_col_pt = 0;
	printf("Which direction would you like to position your  ship? (h or v) \n");
	scanf(" %c", &dir);
	if (dir == 'h')
	{
		while (check == 0)
		{
			printf("Which row number would you like to place the ship?\n");
			scanf("%d", &start_row_pt);
			printf("Which column number would you like to place the ship \n");
			scanf("%d", &start_col_pt);
			if (start_col_pt + ship_len > MAX_COLS || start_col_pt < 0 || start_row_pt < 0 || start_row_pt > 9)
			{
				printf("ship is out of bounds! Try again!\n");
				continue;
			}

			int overlap = 0;
			for (int i = 0; i < ship_len; i++)
			{
				if (board[start_row_pt][start_col_pt + i] != '~')
				{
					overlap = 1;
					break;
				}
			}
			if (overlap)
			{
				printf("There is already a ship there. Please place somewhere else!\n");
				continue;
			}
			for (int i = 0; i < ship_len; i++)
			{
				board[start_row_pt][start_col_pt + i] = symbol;
			}
			check = 1;
		}
	}
	else if (dir == 'v')
	{
		while (check == 0)
		{
			printf("Which column number would you like to place the ship?\n");
			scanf("%d", &start_col_pt);
			printf("Which row number would you like to place the ship (from 0-9)(carrier is 5 long, keep in mind!)\n");
			scanf("%d", &start_row_pt);
			if (start_row_pt + ship_len > MAX_ROWS || start_row_pt < 0 || start_col_pt < 0 || start_col_pt > 9)
			{
				printf("ship is out of bounds! Try again!\n");
				continue;
			}

			int overlap = 0;
			for (int i = 0; i < ship_len; i++)
			{
				if (board[start_row_pt + i][start_col_pt] != '~')
				{
					overlap = 1;
					break;
				}
			}
			if (overlap)
			{
				printf("There is already a ship there. Please place somewhere else!\n");
				continue;
			}
			for (int i = 0; i < ship_len; i++)
			{
				board[start_row_pt + i][start_col_pt] = symbol;
			}
			check = 1;
		}
	}
}

void place_random_ship(char board[][MAX_COLS], int ship_len, int dir, int* start_row_pt, int* start_col_pt, char symbol)
{
	for (int i = 0; i < ship_len; i++)
	{
		if (dir == 0)//horizontal
		{
			board[*start_row_pt][*start_col_pt + i] = symbol;
		}
		else {
			board[*start_row_pt + i][*start_col_pt] = symbol;
		}
	}
}

void place_all_ships(char board[][MAX_COLS])
{
	int direction = 0, start_row = 0, start_col = 0;
	int ships[5] = { 5,4,3,3,2 };
	char symbols[5] = { 'c','b','r','s','d' };
	for (int i = 0; i < 5; i++)
	{
		direction = gen_dir();
		gen_start_pt(board, ships[i], direction, &start_row, &start_col);
		place_random_ship(board, ships[i], direction, &start_row, &start_col, symbols[i]);
	}
}

void shots(char board[][MAX_COLS], int* shot_row, int* shot_col)
{
	int check = 0;
	while (check == 0)
	{
		printf("What row would you like to shoot in? \n");
		scanf("%d", shot_row);
		printf("What column would you like to shoot in? \n");
		scanf("%d", shot_col);
		if (*shot_row < 0 || *shot_row >= MAX_ROWS || *shot_col < 0 || *shot_col >= MAX_COLS)
		{
			printf("Invalid Shot, Please input again!\n");
		}
		else if (board[*shot_row][*shot_col] == 'm' || board[*shot_row][*shot_col] == 'h') {
			printf("You already shot there! Try again\n");
		}
		else {
			printf("Player shot! at (%d, %d)!\n", *shot_row, *shot_col);
			system("pause");
			check = 1;
		}
	}
}

void shot_check(char board[][MAX_COLS], Gamelog* log)
{
	FILE* input = fopen("p1.txt", "a");
	int row = 0, col = 0;
	shots(board, &row, &col);
	log->shots++;
	if (board[row][col] == 'c' || board[row][col] == 'b' || board[row][col] == 'r' || board[row][col] == 's' || board[row][col] == 'd')
	{
		printf("HIT!\n");
		system("pause");
		char ship = board[row][col] = 0;
		board[row][col] = 'h';

		log->hits++;

		int stillExists = 0;
		for (int i = 0; i < MAX_ROWS; i++)
		{
			for (int j = 0; j < MAX_COLS; j++)
			{
				if (board[i][j] == ship)
				{
					stillExists = 1;
				}
			}
		}
		fprintf(input, "(%d, %d), %c\n", row, col, board[row][col]);
		if (!stillExists && ship == 'c' && !log->carrier_sunk)
		{
			fprintf(input, "CARRIER SHIP SUNK!\n");
			log->carrier_sunk = 1;
		}
		else if (!stillExists && ship == 'b' && !log->battleship_sunk)
		{
			fprintf(input, "BATTLESHIP SUNK!\n");
			log->battleship_sunk = 1;
		}
		else if (!stillExists && ship == 'r' && !log->crusier_sunk)
		{
			fprintf(input, "CRUSIER SHIP SUNK!");
			log->crusier_sunk = 1;
		}
		else if (!stillExists && ship == 's' && !log->submarine_sunk)
		{
			fprintf(input, "SUBMARINE SHIP SUNK!");
			log->submarine_sunk = 1;
		}
		else if (!stillExists && ship == 'd' && !log->destroyer_sunk)
		{
			fprintf(input, "DESTROYER SHIP SUNK!");
			log->destroyer_sunk = 1;
		}
	}
	else {
		printf("MISS!\n");
		system("pause");
		board[row][col] = 'm';
		fprintf(input, "(%d, %d), %c\n", row, col, board[row][col]);
		log->misses++;
	}
	if (log->shots > 0)
	{
		log->hits_to_miss = (log->hits / (double)(log->shots) * 100);
	}
	fclose(input);
}

void random_shot(int* shot_row, int* shot_col)
{
	*shot_row = rand() % MAX_ROWS;
	*shot_col = rand() % MAX_COLS;
}

void shot_check2(char board[][MAX_COLS], Gamelog* log)
{
	FILE* input1 = fopen("cmp.battlelog.txt", "a");
	int row = 0, col = 0;
	do
	{
		random_shot(&row, &col);
	} while (board[row][col] == 'h' || board[row][col] == 'm');
	printf("Computer shot! at (%d, %d)!\n", row, col);
	system("pause");
	log->shots++;
	if (board[row][col] == 'c' || board[row][col] == 'b' || board[row][col] == 'r' || board[row][col] == 's' || board[row][col] == 'd')
	{
		printf("HIT!\n");
		system("pause");
		char ship = board[row][col] = 0;
		board[row][col] = 'h';

		log->hits++;

		int stillExists = 0;
		for (int i = 0; i < MAX_ROWS; i++)
		{
			for (int j = 0; j < MAX_COLS; j++)
			{
				if (board[i][j] == ship)
				{
					stillExists = 1;
				}
			}
		}
		fprintf(input1, "(%d, %d), %c\n", row, col, board[row][col]);
		if (!stillExists && ship == 'c' && !log->carrier_sunk)
		{
			fprintf(input1, "CARRIER SHIP SUNK!\n");
			log->carrier_sunk = 1;
		}
		else if (!stillExists && ship == 'b' && !log->battleship_sunk)
		{
			fprintf(input1, "BATTLESHIP SUNK!\n");
			log->battleship_sunk = 1;
		}
		else if (!stillExists && ship == 'r' && !log->crusier_sunk)
		{
			fprintf(input1, "CRUSIER SHIP SUNK!");
			log->crusier_sunk = 1;
		}
		else if (!stillExists && ship == 's' && !log->submarine_sunk)
		{
			fprintf(input1, "SUBMARINE SHIP SUNK!");
			log->submarine_sunk = 1;
		}
		else if (!stillExists && ship == 'd' && !log->destroyer_sunk)
		{
			fprintf(input1, "DESTROYER SHIP SUNK!");
			log->destroyer_sunk = 1;
		}
	}
	else {
		printf("COMPUTER MISS!\n");
		system("pause");
		board[row][col] = 'm';
		fprintf(input1, "(%d, %d), %c\n", row, col, board[row][col]);
		log->misses++;
	}
	if (log->shots > 0)
	{
		log->hits_to_miss = (log->hits / (double)(log->shots) * 100);
	}
	fclose(input1);
}

void win_loss(int result, Gamelog* log)
{
	if (result == 0)
	{
		log->losses++;
	}
	else
	{
		log->wins++;
	}
}

void print_to_file(Gamelog log1, Gamelog log2)
{
	FILE* output = fopen("output.txt", "w");
	fprintf(output, "PLAYER 1\n");
	fprintf(output, "Shots: %d\n", log1.shots);
	fprintf(output, "Hits: %d\n", log1.hits);
	fprintf(output, "Misses: %d\n", log1.misses);
	fprintf(output, "Hit to Miss Percentage: %d\n", log1.hits_to_miss);
	fprintf(output, "Wins: %d\n", log1.wins);
	fprintf(output, "Losses: %d\n", log1.losses);
	fprintf(output, "\n");
	fprintf(output, "\n");
	fprintf(output, "\n");
	fprintf(output, "COMPUTER\n");
	fprintf(output, "Shots: %d\n", log2.shots);
	fprintf(output, "Hits: %d\n", log2.hits);
	fprintf(output, "Misses: %d\n", log2.misses);
	fprintf(output, "Hit to Miss Percentage: %d\n", log2.hits_to_miss);
	fprintf(output, "Wins: %d\n", log2.wins);
	fprintf(output, "Losses: %d\n", log2.losses);
	fclose(output);
}

void print_p1_log()
{

}
void print_cmp_log();