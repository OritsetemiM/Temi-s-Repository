#include "header.h"
void print_game_rules(void)
{
	printf("The scorecard used for Yahtzee is composed of two sections. A upper section and a lower section.A total of thirteen boxes or thirteen scoring combinations are divided amongst the sections.The upper section consists of boxes that are scored by summing the value of the dice matching the faces of the box.If a player rolls four 3's, then the  score placed in the 3's box is the sum of the dice which is 12. Once a player has chosen to score a box, it may not be changed and the combination is no longer in play for future rounds.If the sum of the scores in the upper section is greater than or equal to 63, then 35 more points are added to the players overall score as a bonus. The lower section contains a number of poker like combinations.See the table provided below : \n");
}

int game_menu_choice()
{
	char choice = '\0';
	printf("Would you like to Print Game Rules(r), Play Yahtzee(p), or Exit Game(e)\n");
	scanf(" %c", &choice);
	if (choice == 'r')
	{
		return 2;
	}
	else if (choice == 'p')
	{
		return 1;
	}
	else if (choice == 'e')
	{
		return 0;
	}
	else
	{
		return -1;
	}
}
// preconditions: Dice array and the size of that array
void roll_dice(int dice[], int size)
{
	for (int i = 0; i < size; i++)
	{
		dice[i] = (rand() % 6) + 1;
	}
}
// preconditions: Dice array and the size of that array
void display_dice(int dice[], int size)
{
	for (int i = 0; i < size; i++)
	{
		printf("%d ", dice[i]);
	}
}
// preconditions: Dice array and the size of that array
void reroll_dice(int dice[], int size)
{
	int numDie = 0;
	int dieNum = 0;
	printf("How many die would you like to reroll? \n");
	scanf("%d", &numDie);
	for (int i = 0; i < numDie; i++)
	{
		printf("Which dice would you like to reroll? \n");
		scanf("%d", &dieNum);
		if (dieNum >= 1 && dieNum <= size)
		{
			dice[dieNum - 1] = (rand() % 6) + 1;
		}
		else {
			printf("Invalid Response! Please input again");
			i--;
		}
	}
}
// preconditions: Dice array and the number the user inputted for the sum of numbers they want added to their score
int sum_of_numbers(int dice[], int number)
{
	int sum = 0;
	for (int i = 0; i < 5; i++)
	{
		if (dice[i] == number)
		{
			sum += number;
		}
	}
	return sum;
}
// preconditions: Dice array and the size of the array (uses freqency table)
int three_of_a_kind(int dice[], int size)
{
	int freq[7] = { 0 };
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		freq[dice[i]]++;
		sum += dice[i];
	}
	for (int i = 1; i <= 6; i++)
	{
		if (freq[i] >= 3)
		{
			return sum;
		}
	}
	return 0;
}
// preconditions: Dice array and the size of the array (uses freqency table)
int four_of_a_kind(int dice[], int size)
{
	int freq[7] = { 0 };
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		freq[dice[i]]++;
		sum += dice[i];
	}
	for (int i = 1; i <= 6; i++)
	{
		if (freq[i] >= 4)
		{
			return sum;
		}
	}
	return 0;
}
// preconditions: Dice array and the size of the array (uses freqency table)
int yahtzee(int dice[], int size)
{
	int freq[7] = { 0 };
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		freq[dice[i]]++;
	}
	for (int i = 1; i <= 6; i++)
	{
		if (freq[i] >= 5)
		{
			sum = 50;
			return sum;
		}
	}
	return 0;
}
// preconditions: Dice array and the size of the array
int chance(int dice[], int size)
{
	int sum = 0;
	for (int i = 0; i < size; i++)
	{
		sum += dice[i];
	}
	return sum;
}


//preconditions: the scorecard and the size of the scorecard, needed for initalization
void init_scorecard(int* scorecard_ptr, int size)
{
	int index = 0;

	for (; index < size; ++index)
	{
		scorecard_ptr[index] = -1;
	}
}
//preconditions: the scorecard and the size of the scorecard, needed for printing to the screen
void display_scorecard(int* scorecard_ptr, int size)
{
	for (int i = 0; i < size; i++)
	{
		printf("%d ", scorecard_ptr[i]);
	}
}
//preconditions: the scorecard, the size of the scorecard, the index of the number of the scoring choice the user picked, 
// and the score the user got for the category so it can be shown when the scorecard is displayed
void score_to_scorecard(int* scorecard_ptr, int size, int index, int score)
{
	for (int i = 1; i < size; i++)
	{
		if (index == i)
		{
			scorecard_ptr[i-1] = score;
		}
	}
}
// preconditions: Dice array and the size of the array (uses freqency table)
int full_house(int dice[], int size)
{
	int freq[7] = { 0 };
	int check_for_2 = 0;
	int check_for_3 = 0;
	for (int i = 0; i < size; i++)
	{
		freq[dice[i]]++;
	}
	for (int i = 1; i <= 6; i++)
	{
		if (freq[i] == 2)
		{
			check_for_2 = 1;
		}
		else if (freq[i] == 3)
		{
			check_for_3 = 1;
		}
	}
	if (check_for_2 == 1 && check_for_3 == 1)
	{
		
		return 25;
	}
	return 0;
}
// preconditions: Dice array and the size of the array (uses freqency table)
int small_straight(int dice[], int size)
{
	int freq[7] = { 0 };
	int streak = 0;
	int check = 0;
	for (int i = 0; i < size; i++)
	{
		freq[dice[i]]++;
	}
	for (int i = 1; i <= 6; i++)
	{
		if (freq[i] >= 1)
		{
			check++;
			if (streak < check)
			{
				streak = check;
			}
		}
		else if (freq[i] == 0)
		{
			check = 0;
		}
	}
	if (streak >= 4)
	{
		return 30;
	}
	return 0;
}
// preconditions: Dice array and the size of the array (uses freqency table)
int large_straight(int dice[], int size)
{
	int freq[7] = { 0 };
	int streak = 0;
	int check = 0;
	for (int i = 0; i < size; i++)
	{
		freq[dice[i]]++;
	}
	for (int i = 1; i <= 6; i++)
	{
		if (freq[i] >= 1)
		{
			check++;
			if (streak < check)
			{
				streak = check;
			}
		}
		else if (freq[i] == 0)
		{
			check = 0;
		}
	}
	if (streak >= 5)
	{
		return 40;
	}
	return 0;
}
