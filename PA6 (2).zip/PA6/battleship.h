#ifndef PA6_H
#define PA6_H

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>

#define MAX_ROWS 10
#define MAX_COLS 10
typedef struct gamelog
{
	int hits;
	int misses;
	int shots;
	int hits_to_miss;
	int wins;
	int losses;

	int carrier_sunk;
	int battleship_sunk;
	int crusier_sunk;
	int submarine_sunk;
	int destroyer_sunk;
}Gamelog;
void print_rules();
void init_board(char board[][MAX_COLS], int num_rows, int num_cols);
void print_board(char board[][MAX_COLS], int num_rows, int num_cols, int player);
int select_who_starts_first(void);
void gen_start_pt(char board[][MAX_COLS], int ship_len, int dir, int* start_row_pt, int* start_col_pt);
void randomly_place_ships(char board[][MAX_COLS], int ship_len, int dir, int* start_row_pt, int* start_col_pt);
int gen_dir();
void place_all_ships(char board[][MAX_COLS]);
void manually_place_ships_on_board(char board[][MAX_COLS], int ship_len, char symbol);
void random_place_ships(int ship_len, int dir, int* start_row_pt, int* start_col_pt);
void shots(char board[][MAX_COLS], int* shot_row, int* shot_col);
void shot_check(char board[][MAX_COLS], Gamelog* log);
void random_shot(int* shot_row, int* shot_col);
void shot_check2(char board[][MAX_COLS], Gamelog* log);
void win_loss(int result, Gamelog* log);
void print_to_file(Gamelog log1, Gamelog log2);
#endif