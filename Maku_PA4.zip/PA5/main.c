#include "header.h"

int main()
{
	char answer = '\0';
	int game_answer = 0;
	double bank_balance = 0;
	double wager = 0.0;
	double check_wager = 0;
	double over_bet = 0.0;
	int sum_dice = 0;
	int w_or_l = 0;
	int loss_niether = 0;
	int new_point_value = 0;
	int game_count = 0;
	double initial_bank_balance = 0;
	int rolling = 0;
	srand(time(NULL));



	do {
		if (game_count == 0) {
			printf("Would you like to: Play Craps(p), Display Rules(d), or Exit Game(e)?:  ");
		}
		else {
			printf("Would you like to continue playing? Play again(p), Display Rules(d), or Exit Game(e)?:  ");
		}
		scanf(" %c", &answer);
		printf(" \n");
		printf(" \n");
		printf(" \n");
		game_answer = play_game(answer);
		if (game_answer == 0) {
			printf("Thanks For Playing! Have A Good Day!\n");
			printf("You left the game with $%.2lf in your bank account. \n", bank_balance);
			if (initial_bank_balance > bank_balance)
			{
				initial_bank_balance -= bank_balance;
				printf("You lost $%.2lf during your time playing the game.", initial_bank_balance);
			}
			else if(initial_bank_balance < bank_balance)
			{
				bank_balance -= initial_bank_balance;
				printf("You earned $%.2lf during your time playing the game!!\n", initial_bank_balance);
			}
			else {
				printf("You did lose or gain any money during the game!\n");
			}
			printf(" \n");
			printf(" \n");
			printf(" \n");
			game_answer = 0;

		}
		else if (game_answer == 1)
		{
			game_count += 1;
			int die1 = 0, die2 = 0;
			if (bank_balance != 0)
			{
				printf("You have $%.2lf in your account for this round.\n ", bank_balance);
				printf(" \n");
				printf(" \n");
				printf(" \n");
			}

			else if (bank_balance == 0 && game_count != 1)
			{
				bank_balance = 10.00;
				printf("Someone in the casino gave you $%.2lf since you lost all your money!\n", bank_balance);
				printf("You now have $%.2lf in your account for this round.\n ", bank_balance);

			}
			else {
				bank_balance = get_bank_balance();
				initial_bank_balance = bank_balance;
			}
			chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
			wager = get_wager_amount();
			chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
			check_wager = check_wager_amount(wager, bank_balance);
			if (check_wager == 0)
			{
				over_bet = over_bet_amount(wager, bank_balance);
				printf("You bet $%.2lf over you bank balance, try again! (WARNING if bet is over the limit, game will end: \n", over_bet);
				chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
				wager = get_wager_amount();
				chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
				check_wager = check_wager_amount(wager, bank_balance);
				over_bet = over_bet_amount(wager, bank_balance);
				if (check_wager == 0)
				{
					printf("Sorry you bet $%.2lf over your bank balance, game will end...\n");
					printf(" \n");
					printf(" \n");
					printf(" \n");
					continue;
				}
			}
			else
			{
				printf("Thanks for the bet! LETS PLAY!!\n");
				system("pause");
			}

			while (w_or_l != -1) {
				rolling = 1;
				die1 = roll_die();
				die2 = roll_die();
				sum_dice = calculate_sum_dice(die1, die2);
				printf("You rolled a %d and a %d, the sum is %d\n", die1, die2, sum_dice);
				system("pause");
				w_or_l = is_win_loss_or_point(sum_dice);
				if (w_or_l == 1)
				{
					chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
					printf("You won the $%.2lf you bet\n", wager);
					system("pause");
					bank_balance = adjust_bank_balance(bank_balance, wager, w_or_l);
					printf(" \n");
					printf(" \n");
					printf(" \n");
					rolling = 0;
					break;
				}
				else if (w_or_l == 0)
				{
					chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
					printf("Dang You lost the $%.2lf you bet! \n", wager);
					system("pause");
					bank_balance = adjust_bank_balance(bank_balance, wager, w_or_l);
					printf(" \n");
					printf(" \n");
					printf(" \n");
					rolling = 0;
					break;
				}
				else {
					new_point_value = sum_dice;
					do {
						printf("You roll again\n");
						die1 = roll_die();
						die2 = roll_die();
						sum_dice = calculate_sum_dice(die1, die2);
						printf("You rolled a %d and a %d, the sum is %d\n", die1, die2, sum_dice);
						system("pause");
						w_or_l = is_point_loss_or_neither(sum_dice, new_point_value);
					} while (w_or_l == -1);
					if (w_or_l == 1)
					{
						chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
						printf("$%.2lf is added to your bank account\n", wager);
						system("pause");
						bank_balance = adjust_bank_balance(bank_balance, wager, w_or_l);
						printf(" \n");
						printf(" \n");
						printf(" \n");
						rolling = 0;
						break;
					}
					else if (w_or_l == 0)
					{
						chatter_messages(game_count, rolling, wager, w_or_l, initial_bank_balance, bank_balance);
						printf("you lost $%.2lf from your bank account! \n", wager);
						system("pause");
						bank_balance = adjust_bank_balance(bank_balance, wager, w_or_l);
						printf(" \n");
						printf(" \n");
						printf(" \n");
						rolling = 0;
						break;
					}
				}
			}
		}
		else if (game_answer == 2) {
			print_game_rules();
		}
		else if (game_answer == -1)
		{
			printf("Invalid Response! Carefull!\n");
			printf(" \n");
			printf(" \n");
			printf(" \n");
		}

	} while(game_answer != 0);
	return 0;
	
}