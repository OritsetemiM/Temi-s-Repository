#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h> // rand (), srand ()
#include <time.h> // time ()


void print_game_rules(void); // function that will print out the game rules
double get_bank_balance(void); // function that will get/ask for the back balance of the user
double get_wager_amount(void); // function that will get the amount from how much the user is wagering
int check_wager_amount(double wager, double balance);
int roll_die(void); // simulates a dice roll
double over_bet_amount(double wager_amount, double balance_amount); // function that will calculate the amount over the user bet
int calculate_sum_dice(int die1_value, int die2_value); //adds the 2 dice rolls together
int is_win_loss_or_point(int sum_dice); // determines the reslut of the sum of the dice
int is_point_loss_or_neither(int sum_dice, int point_value); //determines if the point is a loss or neither after the first rule
double adjust_bank_balance(double bank_balance, double wager_amount, int add_or_subtract); // adjusts the bank account from the wager (losing or adding money to the account)
void chatter_messages(int number_rolls, int win_loss_neither, double initial_bank_balance, double current_bank_balance); //chatter box messages that will send messages based on events in the game 
int play_game(char answer); // function to find out if the player still wants to play the game
int is_valid_input(int choice);
void chatter_messages(int game_count, int rolling, double wager, int win_loss_neither, double initial_bank_balance, double current_bank_balance);
