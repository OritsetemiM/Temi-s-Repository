#include "header.h"
/* shuffle cards in deck */

void shuffle(int wDeck[][13])
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */

	/* for each of the 52 cards, choose slot of deck randomly */
	for (card = 1; card <= 52; card++)
	{
		/* choose new random location until unoccupied slot found */
		do
		{
			row = rand() % 4;
			column = rand() % 13;
		} while (wDeck[row][column] != 0);

		/* place card number in chosen slot of deck */
		wDeck[row][column] = card;
	}
}

/* deal cards in deck */
void deal(Hand* h, const int wDeck[][13], const char* wFace[], const char* wSuit[], int num_cards, int* current_card, int player_or_dealer)
{
	int row = 0;    /* row number */
	int column = 0; /*column number */
	int card = 0;   /* card counter */
	int count = 0;
	/* deal each of the 52 cards */
	for (card = *current_card; card <= 52 && count < num_cards; card++)
	{
		/* loop through rows of wDeck */
		for (row = 0; row <= 3; row++)
		{
			/* loop through columns of wDeck for current row */
			for (column = 0; column <= 12; column++)
			{
				/* if slot contains current card, display card */
				if (wDeck[row][column] == card)
				{
					h->card[count].face_value = column;
					h->card[count].suit_value = row;
					if (player_or_dealer == 1)
					{
						printf("-\n");
					}
					else
					{
						printf("%5s of %-8s%c\n", wFace[column], wSuit[row], card);
					}
					count++;
				}
			}
		}
	}
	*current_card = card + 1;
}

void print_rules()
{
	printf("==============================\n"
		"         POKER RULES          \n"
		"==============================\n\n"
		"Goal: Make the best 5-card hand.\n\n"
		"Game Steps:\n"
		"1. Each player gets 5 cards.\n"
		"2. Bet, check, or fold.\n"
		"3. You can trade up to 3 cards.\n"
		"4. Final round of betting.\n"
		"5. Best hand wins the pot.\n\n"
		"Hand Rankings:\n"
		"1. Royal Flush\n"
		"2. Straight Flush\n"
		"3. Four of a Kind\n"
		"4. Full House\n"
		"5. Flush\n"
		"6. Straight\n"
		"7. Three of a Kind\n"
		"8. Two Pair\n"
		"9. One Pair\n"
		"10. High Card\n\n"
		"Betting Options:\n"
		"- Check: Pass without betting\n"
		"- Bet: Wager chips\n"
		"- Call: Match a bet\n"
		"- Raise: Increase the bet\n"
		"- Fold: Quit the hand\n\n"
		"==============================\n");
}

int isPair(Hand* h)
{
	int freq[13] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].face_value]++;
	}
	for (int i = 0; i < 13; i++)
	{
		if (freq[i] == 2)
		{
			return 1;
		}
	}
	return 0;
}



int isTwoPair(Hand* h)
{
	int pair_count = 0;
	int freq[13] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].face_value]++;
	}
	for (int i = 0; i < 13; i++)
	{
		if (freq[i] == 2)
		{
			pair_count++;
		}
	}
	if (pair_count == 2)
	{
		return 2;
	}
	return 0;
}

int isThreeOfKind(Hand* h)
{
	int freq[13] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].face_value]++;
	}
	for (int i = 0; i < 13; i++)
	{
		if (freq[i] == 3)
		{
			return 3;
		}
	}
	return 0;
}

int isFourOfKind(Hand* h)
{
	int freq[13] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].face_value]++;
	}
	for (int i = 0; i < 13; i++)
	{
		if (freq[i] == 4)
		{
			return 4;
		}
	}
	return 0;
}

int isFullHouse(Hand* h)
{
	int has_three = 0;
	int has_two = 0;
	int freq[13] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].face_value]++;
	}
	for (int i = 0; i < 13; i++)
	{
		if (freq[i] == 3)
		{
			has_three = 1;
		}
		else if (freq[i] == 2)
		{
			has_two = 1;
		}
		if (has_two == 1 && has_three == 1)
		{
			return 5;
		}
	}
	return 0;
}

int isFlush(Hand* h)
{
	int freq[4] = { 0 };
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].suit_value]++;
	}
	for (int i = 0; i < 4; i++)
	{
		if (freq[i] == 5)
		{
			return 6;
		}
	}
	return 0;
}

int isStraight(Hand* h)
{
	int freq[13] = { 0 };
	int streak = 0;
	int check = 0;
	for (int i = 0; i < 5; i++)
	{
		freq[h->card[i].face_value]++;
	}
	for (int i = 0; i < 13; i++)
	{
		if (freq[i] >= 1)
		{
			check++;
			if (streak < check)
			{
				streak = check;
			}
		}
		else if (freq[i] == 0)
		{
			check = 0;
		}
	}
	if (streak >= 5)
	{
		return 7;
	}
	if (freq[12] && freq[0] && freq[1] && freq[2] && freq[3])
	{
		return 7;
	}
	return 0;
}

void replace_card(Hand* h, int* current_card, const int wDeck[][13], const char* wFace[], const char* wSuit[])
{
	int num_card = 0;
	int replace_card = 0;
	int count = 0;
	int row = 0;
	int column = 0;
	printf("How many cards would you like to replace (up to 3 cards): \n");
	scanf("%d", &num_card);
	for (int i = 0; i < num_card; i++)
	{
		printf("What is the position of the cards you would like to replace? (1-5): ");
		scanf("%d", &replace_card);
		int found = 0;
		int card = 0;
		for (card = *current_card; card <= 52 && !found; card++)
		{
			/* loop through rows of wDeck */
			for (row = 0; row <= 3; row++)
			{
				/* loop through columns of wDeck for current row */
				for (column = 0; column <= 12; column++)
				{
					/* if slot contains current card, display card */
					if (wDeck[row][column] == card)
					{
						h->card[replace_card - 1].face_value = column;
						h->card[replace_card - 1].suit_value = row;
						printf("NEW CARD: \n");
						printf("%5s of %-8s%c\n", wFace[column], wSuit[row], card);
						*current_card = card + 1;
						found++;
					}
				}
			}
		}
	}
	system("pause");
	printf("UPDATED PLAYER HAND: \n");
	for (int j = 0; j < 5; j++)
	{
		int face = h->card[j].face_value;
		int suit = h->card[j].suit_value;
		printf("%5s of %-8s\n", wFace[face], wSuit[suit]);
	}
}

int check_highest_card(int pair, int two_pair, int three_of_a_kind, int four_of_a_kind, int full_house, int flush, int straight)
{
	int highest_value = 0;
	if (pair != 0)
	{
		highest_value = pair;
	}
	if (two_pair != 0)
	{
		highest_value = two_pair;
	}
	if (three_of_a_kind != 0)
	{
		highest_value = three_of_a_kind;
	}
	if (four_of_a_kind != 0)
	{
		highest_value = four_of_a_kind;
	}
	if (full_house != 0)
	{
		highest_value = full_house;
	}
	if (flush != 0)
	{
		highest_value = flush;
	}
	if (straight != 0)
	{
		highest_value = straight;
	}
	return highest_value;
}

void replace_dealer(Hand* h, int* current_card, const int wDeck[][13], const char* wFace[], const char* wSuit[], int highest_card)
{
	printf("DEALER IS REPLACING THEIR CARDS...\n");
	system("pause");
	if (highest_card != 4 && highest_card != 5 && highest_card != 6 && highest_card != 7)
	{
		int freq[13] = { 0 };
		for (int i = 0; i < 5; i++)
		{
			freq[h->card[i].face_value]++;
		}
		int replaced = 0;
		for (int i = 0; i < 5 && replaced < 3; i++)
		{
			if (freq[h->card[i].face_value] == 1)
			{
				int found = 0;

				for (int card = *current_card; card <= 52 && !found; card++)
				{
					/* loop through rows of wDeck */
					for (int row = 0; row <= 3; row++)
					{
						/* loop through columns of wDeck for current row */
						for (int column = 0; column <= 12; column++)
						{
							/* if slot contains current card, display card */
							if (wDeck[row][column] == card)
							{
								h->card[i].face_value = column;
								h->card[i].suit_value = row;
								*current_card = card + 1;
								found = 1;
								replaced++;
								break;
							}
						}
						if (found)
						{
							break;
						}
					}
				}
			}
		}
	}
	printf("DEALER IS REVEALING CARDS...\n");
	system("pause");
	printf("DEALER HAND: \n");
	for (int j = 0; j < 5; j++)
	{
		int face = h->card[j].face_value;
		int suit = h->card[j].suit_value;
		printf("%5s of %-8s\n", wFace[face], wSuit[suit]);
	}
}

void print_final_decks(Hand* h, const char* wFace[], const char* wSuit[])
{
	for (int j = 0; j < 5; j++)
	{
		int face = h->card[j].face_value;
		int suit = h->card[j].suit_value;
		printf("%5s of %-8s\n", wFace[face], wSuit[suit]);
	}
}

void dealer_print_score(int highest_value)
{
	if (highest_value == 1)
	{
		printf("Dealer's best hand is a pair!\n");
	}
	if (highest_value == 2)
	{
		printf("Dealer's best hand is a two-pair!\n");
	}
	if (highest_value == 3)
	{
		printf("Dealer's best hand is a three of a kind!\n");
	}
	if (highest_value == 4)
	{
		printf("Dealer's best hand is a four of a kind!\n");
	}
	if (highest_value == 5)
	{
		printf("Dealer's best hand is a full house!\n");
	}
	if (highest_value == 6)
	{
		printf("Dealer's best hand is a flush!\n");
	}
	if (highest_value == 7)
	{
		printf("Dealer's best hand is a straight!\n");
	}
	if (highest_value == 0)
	{
		printf("Dealer only has high card!\n");
	}
}

void player_print_score(int highest_value)
{
	if (highest_value == 1)
	{
		printf("Players's best hand is a pair!\n");
	}
	if (highest_value == 2)
	{
		printf("Player's best hand is a two-pair!\n");
	}
	if (highest_value == 3)
	{
		printf("Player's best hand is a three of a kind!\n");
	}
	if (highest_value == 4)
	{
		printf("Player's best hand is a four of a kind!\n");
	}
	if (highest_value == 5)
	{
		printf("Player's best hand is a full house!\n");
	}
	if (highest_value == 6)
	{
		printf("Player's best hand is a flush!\n");
	}
	if (highest_value == 7)
	{
		printf("Player's best hand is a straight!\n");
	}
	if(highest_value == 0)
	{
		printf("Player only has high card!\n");
	}
}