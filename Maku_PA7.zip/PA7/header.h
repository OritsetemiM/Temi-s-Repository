// Authors: Deitel & Deitel - C How to Program
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct cards
{
	int face_value;
	int suit_value;

}Cards;

typedef struct hand
{
	Cards card[5];
}Hand;

void shuffle(int wDeck[][13]);
void deal(Hand* h, const int wDeck[][13], const char* wFace[], const char* wSuit[], int num_cards,int* current_card, int player_or_dealer);
void print_rules();
void replace_card(Hand* h, int* current_card, const int wDeck[][13], const char* wFace[], const char* wSuit[]);
int isPair(Hand* h);
int isTwoPair(Hand* h);
int isThreeOfKind(Hand* h);
int isFourOfKind(Hand* h);
int isFullHouse(Hand* h);
int isFlush(Hand* h);
int isStraight(Hand* h);
void replace_dealer(Hand* h, int* current_card, const int wDeck[][13], const char* wFace[], const char* wSuit[], int highest_card);
int check_highest_card(int pair, int two_pair, int three_of_a_kind, int four_of_a_kind, int full_house, int flush, int straight);
void print_final_decks(Hand* h, const char* wFace[], const char* wSuit[]);
void print_score(int highest_value);
void player_print_score(int highest_value);
void dealer_print_score(int highest_value);
