#include "header.h"

int main(void)
{
	int game_answer = 0;
	int current_card = 1;
	Hand player;
	Hand dealer;
	int highest_player = 0;
	int highest_dealer = 0;
	int isPair_dealer = 0;
	int isTwoPair_dealer = 0;
	int isThreeOfKind_dealer = 0;
	int isFourOfKind_dealer = 0;
	int isFullhouse_dealer = 0;
	int isFlush_dealer = 0;
	int isStraight_dealer = 0;
	int isPair_player = 0;
	int isTwoPair_player = 0;
	int isThreeOfKind_player = 0;
	int isFourOfKind_player = 0;
	int isFullhouse_player = 0;
	int isFlush_player = 0;
	int isStraight_player = 0;
	/* initialize suit array */
	const char* suit[4] = { "Hearts", "Diamonds", "Clubs", "Spades" };

	/* initialize face array */
	const char* face[13] = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight",
		"Nine", "Ten", "Jack", "Queen", "King" };

	/* initalize deck array */
	int deck[4][13] = { 0 };

	srand((unsigned)time(NULL)); /* seed random-number generator */
	
	do
	{
		printf("READY TO PLAY POKER? (rules = 2, play = 1, exit = 0)\n");
		scanf("%d", &game_answer);
		if (game_answer == 2)
		{
			print_rules();
			system("pause");
			system("cls");
		}
		else if (game_answer == 1)
		{
			/* initialize suit array */
			const char* suit[4] = { "Hearts", "Diamonds", "Clubs", "Spades" };

			/* initialize face array */
			const char* face[13] = { "Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight",
				"Nine", "Ten", "Jack", "Queen", "King" };

			/* initalize deck array */
			int deck[4][13] = { 0 };

			srand((unsigned)time(NULL)); /* seed random-number generator */
			printf("dealing...\n");
			system("pause");
			shuffle(deck);
			printf("PLAYER:\n");
			deal(&player, deck, face, suit, 5, &current_card, 0);
			printf("\n");
			replace_card(&player, &current_card, deck, face, suit);
			system("pause");
			system("cls");
			printf("DEALER:\n");
			deal(&dealer, deck, face, suit, 5, &current_card, 1);
			printf("\n");
			isPair_dealer = isPair(&dealer);
			isTwoPair_dealer = isTwoPair(&dealer);
			isThreeOfKind_dealer = isThreeOfKind(&dealer);
			isFourOfKind_dealer = isFourOfKind(&dealer);
			isFullhouse_dealer = isFullHouse(&dealer);
			isFlush_dealer = isFlush(&dealer);
			isStraight_dealer = isStraight(&dealer);
			isPair_player = isPair(&player);
			isTwoPair_player = isTwoPair(&player);
			isThreeOfKind_player = isThreeOfKind(&player);
			isFourOfKind_player = isFourOfKind(&player);
			isFullhouse_player = isFullHouse(&player);
			isFlush_player = isFlush(&player);
			isStraight_player = isStraight(&player);
			highest_dealer = check_highest_card(isPair_dealer, isTwoPair_dealer, isThreeOfKind_dealer, isFourOfKind_dealer, isFullhouse_dealer, isFlush_dealer, isStraight_dealer);
			highest_player = check_highest_card(isPair_player, isTwoPair_player, isThreeOfKind_player, isFourOfKind_player, isFullhouse_player, isFlush_player, isStraight_player);
			replace_dealer(&dealer, &current_card, deck, face, suit, highest_dealer);
			highest_dealer = check_highest_card(isPair_dealer, isTwoPair_dealer, isThreeOfKind_dealer, isFourOfKind_dealer, isFullhouse_dealer, isFlush_dealer, isStraight_dealer);
			printf("\n");
			printf("\n");
			printf("\n");
			printf("HERE ARE THE FINAL DECKS...\n");
			system("pause");
			printf("PLAYER:\n");
			print_final_decks(&player, face, suit);
			system("pause");
			printf("DEALER:\n");
			print_final_decks(&dealer, face, suit);
			player_print_score(highest_player);
			system("pause");
			dealer_print_score(highest_dealer);
			system("pause");
			printf("THE WINNER IS...\n");
			system("pause");
			if (highest_player > highest_dealer)
			{
				printf("THE PLAYER WON!!\n");
				system("pause");
			}
			else if (highest_dealer > highest_player)
			{
				printf("THE DEALER WON!!\n");
				system("pause");
			}
			else
			{
				printf("TIE BREAKER!!\n");
				system("pause");
				int index = 0;
				int tie_player = player.card[index].face_value;;
				int tie_dealer = dealer.card[index].face_value;;
				for (index = 1; index < 5; index++)
				{
					if (player.card[index].face_value > tie_player)
					{
						tie_player = player.card[index].face_value;
					}
					if (dealer.card[index].face_value > tie_dealer)
					{
						tie_dealer = dealer.card[index].face_value;
					}
				}
				if (tie_dealer > tie_player)
				{
					printf("THE DEALER WON THE TIEBREAKER!!\n");
					system("pause");
					system("cls");
				}
				else
				{
					printf("THE PLAYER WON THE TIEBREAKER!!\n");
					system("pause");
					system("cls");
				}
			}
		}
		else if(game_answer == 0)
		{
			printf("THANKS FOR PLAYING!");
		}
		else
		{
			printf("INVALID ANSWER! PLEASE ANSWER AGAIN!");
			system("pause");
			system("cls");
		}
	} while (game_answer != 0);
	return 0;
}

//for the dealer check the hand at first then save the cards for the highest score, then with the remaining cards, replace them
//up to three cards.