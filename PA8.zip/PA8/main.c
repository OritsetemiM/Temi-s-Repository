#include "header.h"

int main()
{
	char src[100] = "Hello";
	char dest[100] = "World";
	printf("Before: %s\n", dest);
	my_str_n_cat(src, dest, 2);
	printf("After: %s\n", dest);

	int search = 0;
	int n = 3;
	int list[10] = { 1,2,3,4,5,6,7,8,9,10 };
	search = binary_search(list, 10, n);
	if (search != -1)
	{
		printf("The number %d is at index %d\n", n, search);
	}
	else
	{
		printf("The number was not found\n");
	}


	char* str[] = { "pear", "apple", "bananna", "peach", "kiwi" };
	printf("Before: ");
	for (int i = 0; i < 5; i++)
	{
		printf("%s ", str[i]);
	}
	bubble_sort(str, 5);
	printf("\n");
	printf("After: ");
	for (int i = 0; i < 5; i++)
	{
		printf("%s ", str[i]);
	}
	printf("\n");


	char* string = "racecar";
	int check = 0;
	check = is_palindrome(string, 7);
	if (check) {
		printf("Is a plaindrome!\n");
	}
	else
	{
		printf("Not a palindrome!\n");
	}

	int number = 10;
	int sum = 0;
	sum = sum_primes(number);
	printf("The sum is %d", sum);
	printf("\n");


	char string1[100] = "racecar driver";
	Occurrences objects[128];
	int max_count = 0;
	char max_char = '\0';

	max_occurances(string1, objects, &max_count, &max_char);
	printf("Most frequent char: %c\n", max_char);
	printf("Occurances: %d\n", max_count);
}