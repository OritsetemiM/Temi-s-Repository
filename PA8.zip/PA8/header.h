#define CRT_SECURE_NO_WARNINGS_
#include <stdio.h>
#include <stdlib.h>

void my_str_n_cat(char* src, char* dest, int n);
int binary_search(int list[], int size, int target);
void bubble_sort(char* str[], int n);
int is_palindrome(char str[], int size);
int sum_primes(int n);

typedef struct occurrences
{
	int num_occurrences;
	double frequency;
} Occurrences;

void max_occurances(char* str, Occurrences objects[], int* n, char* c);