#include "header.h"

void my_str_n_cat(char* src, char* dest, int n)
{
	while (*dest != '\0')
	{
		dest++;
	}
	for (int i = 0; i < n && *src != '\0'; i++)
	{
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
}

int binary_search(int list[], int size, int target)
{
	int mid = 0;
	int left = 0;
	int right = size - 1;
	int found = 0;
	int target_index = -1;
	while (!found && left <= right)
	{
		mid = (left + right) / 2;
		if (target == list[mid])
		{
			found = 1;
			target_index = mid;
		}
		if (target < list[mid])
		{
			right = mid - 1;
		}
		if (target > list[mid])
		{
			left = mid + 1;
		}
	}
	return target_index;
}

void bubble_sort(char* str[], int n)
{
	int U = n - 1;
	while (U > 0)
	{
		int C = 1;
		while (C <= U)
		{
			if (strcmp(str[C],str[C - 1]) < 0)
			{
				char* temp = str[C];
				str[C] = str[C - 1];
				str[C - 1] = temp;
			}
			C++;
		}
		U--;

	}
}

int is_palindrome(char* str, int size)
{
	if (size <= 1)
	{
		return 1;
	}

	if (str[0] != str[size - 1])
	{
		return 0;
	}

	return is_palindrome(str + 1, size - 2);
}

int sum_primes(int n)
{
	
	if (n < 2)
	{
		return 0;
	}
	int isPrime = 1;
	for (int i = 2; i < n; i++)
	{
		if (n % i == 0)
		{
			isPrime = 0;
			break;
		}
	}
	if (isPrime)
	{
		return n + sum_primes(n - 1);
	}
	else
	{
		return sum_primes(n - 1);
	}
}

void max_occurances(char* str, Occurrences objects[], int* n, char* c)
{
	for (int i = 0; i < 128; i++) //number of characters initallizing them all to zero
	{
		objects[i].frequency = 0.0;
		objects[i].num_occurrences = 0;
	}
	for (int j = 0; str[j] != '\0'; j++)
	{
		char ch = str[j];
		objects[ch].num_occurrences++;

	}
	for (int k = 0; k < 128; k++)
	{
		objects[k].frequency = (double)objects[k].num_occurrences/strlen(str);
	}

	int max = 0;
	char max_char = '\0';
	for (int l = 0; l < 128; l++)
	{
		if (objects[l].num_occurrences > max)
		{
			max = objects[l].num_occurrences;
			max_char = (char)l;
		}
	}
	printf("The character that appears the most in the string is %c, it shows up %d times\n", max_char, max);
	*n = max;
	*c = max_char;
	
}